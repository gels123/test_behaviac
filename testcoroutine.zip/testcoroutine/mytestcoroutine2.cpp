//#include <coroutine>
//#include <iostream>
//
//class [[nodiscard]] Task {
//public:
//    class promise_type {
//    private:
//        int value = 0;
//    public:
//        promise_type() = default;
//        Task get_return_object() {
//            return Task(std::coroutine_handle<promise_type>::from_promise(*this));
//        }
//        std::suspend_always initial_suspend() noexcept {
//            return {};
//        }
//        std::suspend_never final_suspend() noexcept {
//            return {};
//        }
//        void return_value(int v) noexcept {
//            value = v;
//        }
//        int get_result() {
//            return value;
//        }
//        void unhandled_exception() noexcept {
//        }
//        void resume() {
//            std::coroutine_handle<promise_type>::from_promise(*this).resume();
//        }
//    };
//
//private:
//    std::coroutine_handle<promise_type> handle = nullptr;
//
//public:
//    Task() = delete;
//    Task(Task&& other) {
//        handle = other.handle;
//        other.handle = nullptr;
//    }
//    explicit Task(std::coroutine_handle<promise_type> h) {
//        handle = h;
//    }
//    ~Task() {
//        if (handle) {
//            handle.destroy();
//            handle = nullptr;
//        }
//    }
//    bool await_ready() {
//        return false;
//    }
//    void await_suspend(std::coroutine_handle<promise_type> h) {
//        if (handle) {
//            if (!handle.done()) {
//                handle.promise().resume();
//            }
//        }
//        h.promise().resume();
//    }
//    decltype(auto) await_resume() {
//        return handle.promise().get_result();
//    }
//    int launch()&& {
//        if (handle) {
//            if (!handle.done()) {
//                handle.promise().resume();
//            }
//            return handle.promise().get_result();
//        }
//    }
//};
//
//Task test3() {
//    co_return 3;
//}
//
//Task test1() {
//    co_return 10;
//    //co_return (10 + co_await test3());
//}
//
//Task test2() {
//    int a = 20;
//    a += 30;
//    int b = co_await test1();
//    co_return a + b;
//}
//
//
//int main() {
//    int i1 = test1().launch();
//    ////auto t1 = co_await test1();//����
//    std::cout << "i1=" << i1 << std::endl;
//    //Task task = test1();
//    //int ret = task.get_result();
//    //std::cout << "test1 ret=" << ret << std::endl; // ���: 42
//
//    //int i2 = 0;
//    //int ret2 = test2().launch();
//    //std::cout << "test2 ret2=" << ret2 << std::endl;
//}