#include <stdio.h>
#include <iostream>
#include <string>
#include <memory>
#include <map>
#include <functional>
#include <typeinfo>
#include <tuple>
#include <any>
#include <variant>

class Base {
public:
    virtual void print() = 0;
    virtual ~Base() = default;
};

//using CreateData = std::variant<Son1Data, Son2Data>;

struct Son1Data {
  int a;
  int b;
  Son1Data(int a, int b) : a(a), b(b) {}
};
class Son1 : public Base {
 public:
    Son1() : a(0), b(0) {};
    Son1(int a, int b) {
        this->a = a;
        this->b = b;    
    }
    Son1(std::any ay) { //Ҳ����ʹ��std::variant<Son1Data, Son2Data>;
        try {
        auto data = std::any_cast<Son1Data>(ay);
            this->a = data.a;
            this->b = data.b;
        } catch (const std::bad_any_cast& e) {
            std::cerr << "Son1 Bad any cast: " << e.what() << std::endl;
            throw; // rethrow the exception
        }
    }
    virtual void print() override {
        std::cout << "Son1 a = " << a << " b = " << b << std::endl;
    }
private:
    int a;
    int b;
};

struct Son2Data {
  int a;
  std::string b;
  Son2Data(int a, std::string b) : a(a), b(b) {}
};
class Son2 : public Base {
public:
    Son2() : a(0), b("") {};
    Son2(int a, std::string b) {
        this->a = a;
        this->b = b;
    }
    Son2(std::any ay) { 
        try {
            auto data = std::any_cast<Son2Data>(ay);
            this->a = data.a;
            this->b = data.b;
        } catch (const std::bad_any_cast& e) {
            std::cerr << "Son2 Bad any cast: " << e.what() << std::endl;
            throw; // rethrow the exception
        }
    }
    virtual void print() override {
        std::cout << "Son2 a = " << a << " b = " << b << std::endl;
    }
private:
    int a;
    std::string b;
};


//// ��������ȷ����������, ���岻��
//class Factory {
// public:
//   template <class T, typename... Args>
//   static std::shared_ptr<T> Create(Args&&... args) {
//    return std::make_shared<T>(std::forward<Args>(args)...);
//   }
//};

using BasePtr = std::shared_ptr<Base>;
using CreatorFuncType = std::function<BasePtr(std::any)>;

class Factory {
public:
    template <class U>
    static void Register() {
        auto tp = typeid(U).name();
        mp[tp] = [](std::any ay) -> BasePtr {
            return std::make_shared<U>(ay);
        };
    }

    static BasePtr Create(const std::string& tp, std::any& ay) {
        auto it = mp.find(tp);
        if (it != mp.end()) {
            auto f = it->second;
            return f(ay);
        }
        return nullptr;
    }
private:
    static std::map<std::string, CreatorFuncType> mp;
};

std::map<std::string, CreatorFuncType> Factory::mp{}; // ��̬��Ա���������ʼ��

int main() {
    printf("Hello World!\n");
    // ��������ȷ�������������岻��
    //auto son1 = Factory::Create<Son1>(1, 100);
    //auto son2 = Factory::Create<Son2>(1, "sdfadf");

    Factory::Register<Son1>();
    Factory::Register<Son2>();

    auto name1 = typeid(Son1).name();
    std::any ay1 = Son1Data(1, 100);
    auto son1 = Factory::Create(name1, ay1);
    if (son1)
        son1->print();

    auto name2 = typeid(Son2).name();
    std::any ay2 = Son2Data(2, "Hello World");
    auto son2 = Factory::Create(name2, ay2);
    if (son2)
        son2->print();

    std::tuple tup = std::make_tuple(1, "sdfa");

    return 0;
}