﻿//#include <coroutine>
//#include <iostream>
//#include <thread>
//#include <string>
//
//class future;
//
//class promise
//{
//public:
//    promise() {
//        self = std::coroutine_handle<promise>::from_promise(*this);  // 初始化记录协程handle用以外部进行恢复调用
//    }
//    future get_return_object();
//    std::suspend_always initial_suspend() noexcept {
//        return {}; 
//    }
//    std::suspend_never final_suspend() noexcept {
//        return {}; 
//    }
//    //void return_void() noexcept {
//    //}
//    void return_value(int val) noexcept {
//        value = val; 
//    }
//    int get_value() {
//        return value;
//    }
//    void unhandled_exception() noexcept {}
//    void resume() {
//        self.resume(); 
//    }
//
//public:
//    promise* continuation = nullptr;    // 记录下一个协程栈帧数据
//    std::coroutine_handle<> self = nullptr;
//    int value;
//};
//
//class future
//{
//public:
//    using promise_type = promise;
//    future(promise_type* promise) :promise_(promise) {
//    }
//    bool await_ready() {
//        return false;
//    }
//    void await_suspend(std::coroutine_handle<future::promise_type> handle) {
//        auto& continuation = handle.promise();  // handle 实际上是外层的协程栈帧, 如果是test2调用, 则handle是test1的.
//        promise_->continuation = &continuation; // promise_是本帧的协程栈帧,如果是test2调用,则就是test2的.
//        promise_->resume();                     // 恢复test2的栈帧
//        std::thread([handle]() mutable { 
//            handle(); 
//        }).detach();
//    }
//    int await_resume() {
//        return promise_->get_value();
//    }
//    int launch()&& {
//        if (promise_) {
//            promise_->resume();
//            return promise_->get_value();
//        }
//    }
//    int get_value() {
//        return promise_->get_value();
//    }
//
//private:
//    promise_type* promise_;
//};
//
//future promise::get_return_object() {
//    return { this };
//}
//
//future test2()
//{
//    co_return 10;
//}
//future test1()
//{
//    int num = co_await test2();   // co_await触发跳出
//    co_return 20 + num;
//}
//int main()
//{
//    int i1 = test2().launch();
//    std::cout << "xxxxx i1==" << i1 << "\n";
//    //int i2 = test1().launch();
//    //std::cout << "xxxxx i1==" << i2 << "\n";
//    std::cout << "11.come back to caller becuase of co_await test2\n";
//    std::this_thread::sleep_for(std::chrono::seconds(5));
//    return 0;
//}
//
//
//
