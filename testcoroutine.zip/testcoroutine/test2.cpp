//#include <iostream>
//#include <type_traits>
//
//template<typename T>
//std::enable_if< std::is_integral<T>::value&&!std::is_same_v<T, bool>,void >::type //�����ų�bool
//func(T t) {
//    std::cout << "func(T) is_integral" << std::endl;
//}
//
//template<typename T>
//std::enable_if< std::is_floating_point<T>::value, void >::type 
//func(T t) {
//    std::cout << "func(T) is_floating_point" << std::endl;
//}
//
//template <typename T>
//std::enable_if_t<std::is_same_v<T, bool>,void>
//func(T t) {
//    std::cout << "func(T) bool" << std::endl;
//}
//
//
//int main() {
//    std::cout << "main()" << std::endl;
//    func(1);
//    func(2.0f);
//    func(true);
//    return 0;
//}